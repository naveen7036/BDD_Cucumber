package com.bdd.constant;

public interface SuiteConstants {
	
	public static final int MAX_TIMEOUT = 60;
	public static final int MAX_Element_TIMEOUT = 30;
	public static final int PAGE_LOAD_TIMEOUT = 60;

}