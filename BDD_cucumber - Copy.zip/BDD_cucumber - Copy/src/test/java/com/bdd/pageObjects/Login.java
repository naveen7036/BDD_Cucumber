package com.bdd.pageObjects;

import java.io.IOException;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.asserts.SoftAssert;

import com.cucumber.listener.Reporter;

public class Login extends Page{
	
	Logger logger = Logger.getLogger(Login.class);

	public Login(WebDriver driver) {
		
		super(driver);
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(id = "inputUserEmail")
	private WebElement emailInputBox;
	
	@FindBy(id = "inputUserPassword")
	private WebElement passwordInputBox;
	
	@FindBy(id = "btnUserLogin")
	private WebElement loginButton;	
	
	@FindBy(id = "linkForgotPassword")
	private WebElement forgetPwdLnk;
	
	@FindBy(css = "a[class='button expanded sign-up-btn']")
	private WebElement signUpButton;
	
	@FindBy(css = "div [class$='download-app-img'] img")
	private WebElement mobileImage;
	
	@FindBy(xpath = "//a[@href='/en/properti']")
	private WebElement lnkMyProperties ;
	
	@FindBy(css = "*[class='download-app-icons'] img[src^='/-/media/DubaiProperties/Images/Hero/app-store']")
	private WebElement appStoreImage;
	
	@FindBy(css = "*[class='download-app-icons'] img[src^='/-/media/DubaiProperties/Images/Hero/google-store']")
	private WebElement playStoreImage;
	
	@FindBy(xpath = ".//*[@id='dpMainWrapper']//i[@class='icn-owner fz-4x']/..")
	private WebElement ownerSelectionLnk;
	
	@FindBy(xpath = ".//*[@id='dpMainWrapper']//i[@class='icn-tenant fz-4x']/..")
	private WebElement tenantSelectionLnk;
	
	@FindBy(css = "*[id='userLoginForm'] div[class='dp-alert alert']")
	private WebElement lblIncorrectEmailOrPassword ;
	
	@FindBy(xpath = "//*[@id='userLoginForm']//div[@class='dp-alert alert'] [contains(text(),'account is locked')]")
	private WebElement accountLockedText ;
	
	//====================================================================================================================
			
	/**
	 * This method is used to verify that Login link should be present on the header
	 */

	public boolean verifyemailInputBox() {
		boolean flag = false;
		flag = verifyElementVisible(emailInputBox);
		return flag;
	}
	
	public boolean verifyFieldsOnLogin(){
		boolean flag = false;
		if (verifyElementVisible(emailInputBox) && verifyElementVisible(passwordInputBox)
				&& verifyElementVisible(signUpButton) && verifyElementVisible(loginButton)
				&& verifyElementVisible(forgetPwdLnk) /*&& verifyElementVisible(appStoreImage)
				&& verifyElementVisible(playStoreImage)*/) {
			logger.info("email,passw,signup,forget password,login  button are present");
			flag = true;
		}		
		return flag;
		
	}
	
	public WebElement getAccountLockedText(){
		return accountLockedText;
	}
	
	public WebElement getOwnerSelectionLnk(){
		return ownerSelectionLnk;
	}
	
	
	public WebElement getTenantSelectionLnk(){
		return tenantSelectionLnk;
	}
	
	public WebElement getLoginButton(){
		return loginButton;
	}
	
	public WebElement getEmailInputBox(){
		return emailInputBox;
	}
	
	public WebElement getPasswordInputBox(){
		return passwordInputBox;
	}
	
    public WebElement getForgetPwdLink() {
		
		return forgetPwdLnk;
	}
	
	public void loginIntoApp(String Username, String Password) throws Exception{
		Reporter.addStepLog("Function: loginIntoApp has been called");
		enter(emailInputBox,Username);
		enter(passwordInputBox,Password);
		Click(getEmailInputBox());
		Click(loginButton);
	}
	
	public void enterUserEmail(String Username) throws Exception{
		Reporter.addStepLog("Enter username as: " +Username);
		enter(emailInputBox,Username);
	}
	
	public void enterPassword(String Password) throws Exception{
		Reporter.addStepLog("Enter password as: " +Password);
		enter(passwordInputBox,Password);
	}
	
	public void clickLogin() throws IOException {
		Reporter.addStepLog("Click on login button");
		Click(getEmailInputBox());
		Click(loginButton);
		
	}
	
	public void loginIntoAppMultipleAttempts(String Username, String noOfAttempts) throws Exception{		
		int attempts=Integer.parseInt(noOfAttempts);
		for(int i=1;i<=attempts;i++){
			enter(emailInputBox,Username);
			enter(passwordInputBox,"dasdas");
			Click(getEmailInputBox());
			Click(loginButton);
		}
		
	}
	
	public void clickSignUpButton() throws IOException{
		Click(signUpButton);
	}
	
	public void clickForgetPwdLnk() throws IOException{
		Click(forgetPwdLnk);
	}
	
	public void verifyMyPropertiesOnLogin() {		
		
		SoftAssert s_assert = new SoftAssert();
		boolean flag = false ;
		Reporter.addStepLog("Verify My Property screen after login.");
		if(verifyElementVisible(lnkMyProperties)) {
			
			flag = true;
		
		}
		
		s_assert.assertTrue(flag, "Properties list page should be displayed");
		s_assert.assertAll();		
		
	}
	
	
	public boolean verifyInvalidLogin() {
		
		boolean flag = false;
		
		if(verifyElementVisible(lblIncorrectEmailOrPassword)) {
			
			flag = true ;
			logger.info("Validation for invalid user name and password is displayed");
		}
		
		return flag ;
	}
	
}
