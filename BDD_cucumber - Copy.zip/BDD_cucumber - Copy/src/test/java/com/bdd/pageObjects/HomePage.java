package com.bdd.pageObjects;

import java.io.IOException;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import static java.util.Arrays.asList;
import static org.testng.Assert.fail;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.bdd.initialSetUp.TestBase;
import com.galenframework.api.Galen;
import com.galenframework.api.GalenPageDump;
import com.galenframework.reports.GalenTestInfo;
import com.galenframework.reports.HtmlReportBuilder;
import com.galenframework.reports.model.LayoutReport;




public class HomePage extends Page {
	
	public static WebDriver driver = null;

	public HomePage(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver, this);
		this.driver = driver;
	}
	
	
	public void verifyHomePageLogo() throws IOException {
		
		TestBase tBase = new TestBase();
				
		String pageSpecPath = System.getProperty("user.dir")+"/src/test/resources/PageSpecs/HomePage.spec";
		String reportFolderPath = System.getProperty("user.dir")+"/src/test/resources/PageDump/HomePage/Header";
		
		SoftAssert s_assert = new SoftAssert();
		
		//List<GalenTestInfo>tests = new LinkedList<GalenTestInfo>();
		
        System.out.println("Hello1");
        
        //GalenTestInfo test = GalenTestInfo.fromString("Starbucks Home Page");
        
        System.out.println("Hello2");
        
        //LayoutReport report = Galen.checkLayout(driver,pageSpecPath,asList("Desktop"));
       
        System.out.println("Hello3");
        
        //test.getReport().layout(report,"check Home Page");
        
        //tests.add(test);
        
        //new HtmlReportBuilder().build(tests, "target/GalenReports");
        
        LayoutReport report = tBase.creativeCheckLayout(driver,pageSpecPath,"desktop","Home Page");
        
        if(report.errors() > 0){
        	
        	s_assert.assertFalse(true, "the home page logo spec is not as expected here's the link for Galen Report :"+tBase.GalenTestReportPath);
            System.out.println("UI layout check failed.");
        }else {
   
        	System.out.println("Passed");
        }
        
        s_assert.assertAll();
		//new GalenPageDump("Home Page").dumpPage(driver, pageSpecPath, reportFolderPath);
        
	}
}	


