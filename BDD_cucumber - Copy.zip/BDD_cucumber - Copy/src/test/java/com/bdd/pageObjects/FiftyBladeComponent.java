package com.bdd.pageObjects;

import java.io.IOException;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.asserts.SoftAssert;

import com.bdd.initialSetUp.TestBase;
import com.galenframework.reports.model.LayoutReport;

public class FiftyBladeComponent extends Page{
	
	public static WebDriver driver = null;

	public FiftyBladeComponent(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver, this);
		this.driver = driver;
	}
	
     public void verify50BladeComponent(String deviceType) throws IOException {
			    	
		TestBase tBase = new TestBase();
		tBase.viewPort(deviceType);
				
		String pageSpecPath = System.getProperty("user.dir")+"/src/test/resources/PageSpecs/50BladeComponent.gspec";

        LayoutReport report = tBase.creativeCheckLayout(driver,pageSpecPath,deviceType,"50BladeComponent");
        
        //String reportFolderPath = System.getProperty("user.dir")+"/src/test/resources/PageDump/HomePage/Header";
		//new GalenPageDump("Home Page").dumpPage(driver, pageSpecPath, reportFolderPath);
        
	 }
	
}
