package com.bdd.pageObjects;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.bdd.initialSetUp.TestBase;
import com.cucumber.listener.Reporter;
import com.galenframework.api.GalenPageDump;
import com.galenframework.reports.model.LayoutReport;
import com.galenframework.suite.GalenPageTest;



public class HeaderAndText extends Page{

	public static WebDriver driver = null;

	public HeaderAndText(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver, this);
		this.driver = driver;	}

	
    public void verifyHeaderAndText(String deviceType) throws IOException {
		
		TestBase tBase = new TestBase();
		
		tBase.viewPort(deviceType);
				
		String pageSpecPath = System.getProperty("user.dir")+"/src/test/resources/PageSpecs/HeaderAndText.gspec";

        LayoutReport report = tBase.creativeCheckLayout(driver,pageSpecPath,deviceType,"HeaderAndText");
        
        //String reportFolderPath = System.getProperty("user.dir")+"/src/test/resources/PageDump/HomePage/Header";
		//new GalenPageDump("Home Page").dumpPage(driver, pageSpecPath, reportFolderPath);
        
	 }                    
	    
}
