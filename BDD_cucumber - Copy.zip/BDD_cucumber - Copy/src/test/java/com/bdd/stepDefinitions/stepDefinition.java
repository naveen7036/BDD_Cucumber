package com.bdd.stepDefinitions;

import java.lang.reflect.Method;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.bdd.initialSetUp.BrowserDriver;
import com.bdd.initialSetUp.TestBase;
import com.bdd.pageObjects.Page;
import com.bdd.utils.Util;
import com.cucumber.listener.Reporter;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;


public class stepDefinition  {
	
		private WebDriver driver;
		String methodName;
		String className;
		Object objConstructor;
		Method objMethod ;
	
			
		public void invokeMethod(String methodName) throws Exception {
			
			driver=BrowserDriver.getBrowserInstance();
			String [] arrayOFParams= methodName.split("\\.");
			this.className=arrayOFParams[0];
			this.methodName=arrayOFParams[1];
			
			Method[] objMethods;
			Object objConstructor;
			
            Class aClass = Class.forName("com.bdd.pageObjects."+this.className);
			
			objConstructor = aClass.getDeclaredConstructor(WebDriver.class).newInstance(driver);
			
			objMethods = aClass.getDeclaredMethods();
			
			for(Method m : objMethods) {
				
				if(m.getName().equals(this.methodName)) {
					
					Class [] parameterTypes = m.getParameterTypes();
					this.objMethod = aClass.getDeclaredMethod(this.methodName, parameterTypes);
				}
			}
			           
			this.objConstructor = objConstructor;								
			
		}
		
		@Given("^I navigate browser to \"([^\"]*)\"$")
		public void navigateBrowserTo(String URL) throws Exception {	
			//Delete below two lines and uncomment 3rd line
			System.setProperty("webdriver.chrome.driver", "D:\\Work\\Automation\\chromedriver.exe");
			WebDriver driver = new ChromeDriver();			 
			driver=BrowserDriver.getBrowserInstance();
			Page objPage= new Page(driver);
			TestBase tbase = new TestBase();
			URL = Util.getValFromResource(URL);
			URL = tbase.envURL+URL;
			objPage.navigateTo(driver, URL);
			Reporter.addStepLog("Navigate to the URL :"+URL);
			
		}
		
		@Then("^I enter the  \"([^\"]*)\" as \"([^\"]*)\"$")
		public void enterThe(String methodName , String parameter) throws Exception {	
			invokeMethod(methodName);
            objMethod.invoke(objConstructor,Util.getValFromResource(parameter)); 
			
		}
		
		@Then("^I click the  \"([^\"]*)\"$")
		public void clickThe(String methodName) throws Exception {
			invokeMethod(methodName);
            objMethod.invoke(objConstructor); 
			
		}
		
		@Then("^I verify the \"([^\"]*)\"$")
		public void verifyThe(String methodName) throws Exception {
			invokeMethod(methodName);
            objMethod.invoke(objConstructor);
			
		}
		
		@Then("^I verify the \"([^\"]*)\" on \"([^\"]*)\"$")
		public void verifyCSSProperty(String methodName , String parameter) throws Exception {
			
			invokeMethod(methodName);
            objMethod.invoke(objConstructor,parameter);
            	
		}
		
		@Then("^I generate the \"([^\"]*)\" on \"([^\"]*)\" for \"([^\"]*)\"$")
		public void generatePageDump(String methodName, String deviceType, String pageName) throws Exception {
			
			invokeMethod(methodName);
            objMethod.invoke(objConstructor, deviceType, pageName);
		}
		
		
}
