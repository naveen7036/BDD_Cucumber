package com.bdd.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.Map.Entry;
import javax.mail.BodyPart;
import javax.mail.MessagingException;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMultipart;
import org.apache.commons.codec.binary.Base64;
import org.apache.poi.util.IOUtils;
import com.bdd.initialSetUp.ExtentReport;
import com.bdd.initialSetUp.TestBase;
import com.sendgrid.Attachments;
import com.sendgrid.Content;
import com.sendgrid.Email;
import com.sendgrid.Mail;
import com.sendgrid.Method;
import com.sendgrid.Personalization;
import com.sendgrid.Request;
import com.sendgrid.SendGrid;

public class sendResultEmail extends TestBase{
	
	private String EnvironmentURL = null;
	
	public sendResultEmail(String resultFile,String Recipients) throws IOException {

		   try {
			     //This mail has 2 part, the BODY and the embedded image
	             MimeMultipart multipart = new MimeMultipart("mixed");

	            // first part (the html)
	            BodyPart messageBodyPart = new MimeBodyPart();
	        
		     String upFileName= resultFile.replace("//", "\\");
		     upFileName="\\"+ upFileName+"/report.html";
		     upFileName=System.getProperty("user.dir")+upFileName;

		     System.out.println(upFileName);
	         Map<String, String> input = new HashMap<String, String>();
	         input.put("suite", region);
	         input.put("browser", browserName);
	         input.put("environment", envURL);
	         input.put("rsFile", upFileName);
	         
	            Attachments attachments = new Attachments();
	            attachments.setContent(convertToBase64(".\\src\\test\\resources\\logo-sr-black.png"));
	            attachments.setType("image/png");
	            attachments.setFilename("logo.png");
	            attachments.setDisposition("inline");
	            attachments.setContentId("<image1>");
	            
	        String htmlText = readEmailFromHtml(".\\src\\test\\resources\\ResultEmail.html",input);	         
	        Personalization personalization = new Personalization();
	 		Mail mail = new Mail();
	 		Email from = new Email("starbucksAutomation@sapient.com");
	         String subject = "Automation Result on Environment-" + envURL;
	         String Recipents= Util.getValFromResource(Recipients);
	         String RecipentsArray[]= Recipents.split(",");
	         
	         for(int i=0;i<RecipentsArray.length;i++){
	        	 
	        	 Email to = new Email(RecipentsArray[i]);
	        	 personalization.addTo(to);
	         }
	         mail.setFrom(from);
	         mail.setSubject(subject);

	   
	      Content content = new Content("text/html", htmlText);
	     // Mail mail = new Mail(from, subject, to, content);
	      mail.addPersonalization(personalization);
	      mail.addContent(content);
	     /* Content content1 = new Content();
	         content1.setType("image/png");
	         content1.setValue(".\\src\\test\\resources\\logo-sr-black.png");
	         mail.addContent(content1);
	     */  
	         mail.addAttachments(attachments);
	         
	      SendGrid sg = new SendGrid("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");
	      Request request = new Request();
	            
	      try {
	          request.setMethod(Method.POST);
	          request.setEndpoint("mail/send");
	          request.setBody(mail.build());
	          
	          com.sendgrid.Response response = sg.api(request);
	
	        } 
	        catch (IOException ex) {
	          throw ex;
	        }
	            messageBodyPart.setContent(htmlText, "text/html");
	            multipart.addBodyPart(messageBodyPart); 	                      	            
	                 	         
			    System.out.println("Email Sent");
			   } catch (MessagingException e) {
			    throw new RuntimeException(e);
			   }			   	
	}
	
	//Method to replace the values for keys
	protected String readEmailFromHtml(String filePath, Map<String, String> input)
	{
	      String msg = readContentFromFile(filePath);
	     try{
	    	  Set<Entry<String, String>> entries =input.entrySet();
	          for(Map.Entry<String, String> entry : entries) {
	        	  msg = msg.replace(entry.getKey().trim(),entry.getValue().trim());
	        	  }
	          }catch(Exception exception)
	          {
	              exception.printStackTrace();
	          }
	      return msg;
	}
	
	//Method to read HTML file as a String 
	private String readContentFromFile(String fileName)
	{
	   StringBuffer contents = new StringBuffer();
	
	   try {
	   //use buffering, reading one line at a time
	        BufferedReader reader =new BufferedReader(new FileReader(fileName));
	         try {
	             String line = null; 
	             while (( line = reader.readLine()) != null){
	             contents.append(line);
	             contents.append(System.getProperty("line.separator"));
	              }
	             }finally {
	                reader.close();
	             }
	        } catch (IOException ex){
	          ex.printStackTrace();
	         }
	 return contents.toString();
	}

	public String convertToBase64(String filepath) {
   File file = new File(filepath);
   byte[] fileData = null;
   try {
       fileData = IOUtils.toByteArray(new FileInputStream(file));
   } catch (IOException ex) {
   }
   Base64 x = new Base64();
   String imageDataString = x.encodeAsString(fileData);
		 
		return imageDataString; 	 
}
	
	

}
