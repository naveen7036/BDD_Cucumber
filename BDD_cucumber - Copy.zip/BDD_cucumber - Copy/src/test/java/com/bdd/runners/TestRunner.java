package com.bdd.runners;

import cucumber.api.CucumberOptions;
import cucumber.api.Scenario;
import cucumber.api.testng.TestNGCucumberRunner;
import net.masterthought.cucumber.json.Feature;
import cucumber.api.testng.CucumberFeatureWrapper;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import org.apache.poi.util.SystemOutLogger;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.ChartLocation;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.bdd.initialSetUp.BrowserDriver;
import com.bdd.initialSetUp.ExtentReport;
import com.bdd.initialSetUp.TestBase;
import com.cucumber.listener.ExtentProperties;
import com.cucumber.listener.Reporter;
import com.galenframework.reports.GalenTestInfo;
import com.galenframework.reports.HtmlReportBuilder;


 
@CucumberOptions(
        features = "src\\test\\resources\\features\\CoffeeLandingPage.feature",
        glue = {"com.bdd.stepDefinitions","com.bdd.hooks"},
        tags = {"@SmokeTest","@CoffeeCardGrid_CoffeeLandingPage"},
        plugin={"com.cucumber.listener.ExtentCucumberFormatter:"},
        monochrome = true)
        
       

public class TestRunner extends TestBase {
	
	private TestNGCucumberRunner testNGCucumberRunner;
    public static String upDate;
    
    public static List<GalenTestInfo>tests;
    public static HtmlReportBuilder repObj;  

    
    @BeforeSuite
    public void initBuild() {
    	    		
      setUpEnv();
    	
    }
 
	@BeforeClass(alwaysRun = true)
    public void setUpClass() throws Exception {
		
		System.setProperty("galen.config.file", "src\\test\\resources\\galen.config");	
        testNGCucumberRunner = new TestNGCucumberRunner(this.getClass());
        System.out.println("Setup for report");
        Date date= new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy-HH-mm");
        upDate=sdf.format(date);
        tests = new LinkedList<GalenTestInfo>();
        repObj = new HtmlReportBuilder();
		ExtentReport.extentProperties = ExtentProperties.INSTANCE;
		ExtentReport.extentProperties.setReportPath(System.getProperty("user.dir")+"/test-output/ReportFileForStarBucks/"+ upDate+"_" +browserName+"_report.html");
     }
    
    @Test(groups = "cucumber", description = "Runs Cucumber Feature", dataProvider = "features")
    public void feature(CucumberFeatureWrapper cucumberFeature) {
        testNGCucumberRunner.runCucumber(cucumberFeature.getCucumberFeature());
    }
 
    @DataProvider
    public Object[][] features() {
    	
        return testNGCucumberRunner.provideFeatures();
    }
 
    @AfterClass(alwaysRun = true)
    public void tearDownClass() throws Exception {
       
    	testNGCucumberRunner.finish();
                      
    }
    
    @AfterSuite
    public void onFinishExecution() throws IOException {
    	
    	System.out.println("this is After Suite block");
    	ExtentReport.writeExtentReport();
    	if(!tests.isEmpty()) {
    	   repObj.build(tests,GalenTestReportPath);
    	}else {
    		System.out.println("the Galen report is not generated, could be run errors in spec file.");
    	}
    	TearDown();
    	onFinish();
    	
    }    
    
    
}